package dev.hitmetrics.config;

import dev.hitmetrics.HitMetricsClient;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.concurrent.atomic.AtomicReference;

@Environment(EnvType.CLIENT)
public final class HitMetricsConfigScreen {
    private static final AtomicReference<Screen> PENDING_RESET_BUTTON = new AtomicReference<>();
    private static boolean resetHookRegistered;
    private static Screen liveScreen;
    private static Runnable liveUpdate;

    private HitMetricsConfigScreen() { }

    public static Screen create(Screen parent) {
        registerResetButtonHook();
        HitMetricsConfig config = HitMetricsClient.config();
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.translatable("config.hitmetrics.title"));
        ConfigEntryBuilder entries = builder.entryBuilder();
        ConfigCategory hud = builder.getOrCreateCategory(Component.translatable("config.hitmetrics.category.hud"));
        ConfigCategory features = builder.getOrCreateCategory(Component.translatable("config.hitmetrics.category.features"));

        var xEntry = entries.startIntSlider(Component.translatable("config.hitmetrics.x"), config.xOffset, -500, 500)
                .setDefaultValue(0).setSaveConsumer(value -> config.xOffset = value).build();
        var yEntry = entries.startIntSlider(Component.translatable("config.hitmetrics.y"), config.yOffset, 0, 200)
                .setDefaultValue(30).setSaveConsumer(value -> config.yOffset = value).build();
        var colorEntry = entries.startStrField(Component.translatable("config.hitmetrics.color"), config.color)
                .setDefaultValue("#FFFFFF")
                .setErrorSupplier(value -> HitMetricsConfig.isValidColor(value)
                        ? java.util.Optional.empty()
                        : java.util.Optional.of(Component.translatable("config.hitmetrics.color.invalid")))
                .setSaveConsumer(value -> config.color = value).build();
        var layoutEntry = entries.startEnumSelector(Component.translatable("config.hitmetrics.layout"), HitMetricsConfig.Layout.class, config.layout)
                .setDefaultValue(HitMetricsConfig.Layout.VERTICAL)
                .setEnumNameProvider(value -> Component.translatable("config.hitmetrics.layout." + value.name().toLowerCase()))
                .setSaveConsumer(value -> config.layout = value).build();
        var targetsEntry = entries.startEnumSelector(Component.translatable("config.hitmetrics.targets"), HitMetricsConfig.TargetMode.class, config.targetMode)
                .setDefaultValue(HitMetricsConfig.TargetMode.PLAYERS)
                .setEnumNameProvider(value -> Component.translatable("config.hitmetrics.targets." + value.name().toLowerCase()))
                .setSaveConsumer(value -> config.targetMode = value).build();
        var orderEntry = entries.startEnumSelector(Component.translatable("config.hitmetrics.order"), HitMetricsConfig.IndicatorOrder.class, config.order)
                .setDefaultValue(HitMetricsConfig.IndicatorOrder.DISTANCE_COMBO_BEST)
                .setEnumNameProvider(value -> Component.translatable("config.hitmetrics.order." + value.name().toLowerCase()))
                .setSaveConsumer(value -> config.order = value).build();

        hud.addEntry(xEntry);
        hud.addEntry(yEntry);
        hud.addEntry(colorEntry);
        hud.addEntry(layoutEntry);
        hud.addEntry(targetsEntry);
        hud.addEntry(orderEntry);

        var timerEntry = entries.startBooleanToggle(Component.translatable("config.hitmetrics.combo_timer"), config.comboTimerEnabled)
                .setDefaultValue(true).setSaveConsumer(value -> config.comboTimerEnabled = value).build();
        var soundEntry = entries.startBooleanToggle(Component.translatable("config.hitmetrics.record_sound"), config.recordSoundEnabled)
                .setDefaultValue(true).setSaveConsumer(value -> config.recordSoundEnabled = value).build();
        var volumeEntry = entries.startIntSlider(Component.translatable("config.hitmetrics.record_sound_volume"), config.recordSoundVolume, 0, 100)
                .setDefaultValue(70).setSaveConsumer(value -> config.recordSoundVolume = value).build();
        var warningEntry = entries.startBooleanToggle(Component.translatable("config.hitmetrics.offhand_warning"), config.offhandTotemWarningEnabled)
                .setDefaultValue(true).setSaveConsumer(value -> config.offhandTotemWarningEnabled = value).build();
        features.addEntry(timerEntry);
        features.addEntry(soundEntry);
        features.addEntry(volumeEntry);
        features.addEntry(warningEntry);

        builder.setSavingRunnable(() -> config.save(HitMetricsClient.LOGGER));
        Screen screen = builder.build();
        PENDING_RESET_BUTTON.set(screen);
        liveScreen = screen;
        liveUpdate = () -> {
            config.xOffset = xEntry.getValue();
            config.yOffset = yEntry.getValue();
            if (HitMetricsConfig.isValidColor(colorEntry.getValue())) config.color = colorEntry.getValue();
            config.layout = layoutEntry.getValue();
            config.targetMode = targetsEntry.getValue();
            config.order = orderEntry.getValue();
            config.comboTimerEnabled = timerEntry.getValue();
            config.recordSoundEnabled = soundEntry.getValue();
            config.recordSoundVolume = volumeEntry.getValue();
            config.offhandTotemWarningEnabled = warningEntry.getValue();
        };
        return screen;
    }

    /** Mirrors Cloth Config widget values while the screen is open for a live HUD preview. */
    public static void tickLiveSettings(Minecraft client) {
        if (client != null && client.screen == liveScreen && liveUpdate != null) liveUpdate.run();
    }

    /** Cloth Config has no stable button-entry builder, so a vanilla button is attached to its screen. */
    private static synchronized void registerResetButtonHook() {
        if (resetHookRegistered) return;
        resetHookRegistered = true;
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen != PENDING_RESET_BUTTON.get()) return;
            Button reset = Button.builder(Component.translatable("config.hitmetrics.reset_best"), button -> {
                HitMetricsConfig config = HitMetricsClient.config();
                config.bestCombo = 0;
                HitMetricsClient.TRACKER.onBestComboReset();
                config.save(HitMetricsClient.LOGGER);
                HitMetricsClient.LOGGER.info("HitMetrics best combo reset from config screen");
                button.setMessage(Component.translatable("config.hitmetrics.reset_done"));
            }).bounds(scaledWidth - 154, 6, 148, 20).build();
            Screens.getWidgets(screen).add(reset);
        });
    }
}
