package dev.hitmetrics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Persistent, client-only settings stored in config/hitmetrics.json. */
@Environment(EnvType.CLIENT)
public final class HitMetricsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("hitmetrics.json");

    public int xOffset = 0;
    public int yOffset = 30;
    public String color = "#FFFFFF";
    public Layout layout = Layout.VERTICAL;
    public TargetMode targetMode = TargetMode.PLAYERS;
    public IndicatorOrder order = IndicatorOrder.DISTANCE_COMBO_BEST;
    public int bestCombo = 0;
    public boolean comboTimerEnabled = true;
    public boolean recordSoundEnabled = true;
    public int recordSoundVolume = 70;
    public boolean offhandTotemWarningEnabled = true;

    public static HitMetricsConfig load(Logger logger) {
        if (!Files.isRegularFile(PATH)) {
            HitMetricsConfig defaults = new HitMetricsConfig();
            defaults.save(logger);
            logger.info("HitMetrics config created with default values");
            return defaults;
        }

        try {
            String json = Files.readString(PATH, StandardCharsets.UTF_8);
            JsonObject fields = JsonParser.parseString(json).getAsJsonObject();
            HitMetricsConfig loaded = GSON.fromJson(json, HitMetricsConfig.class);
            if (loaded == null) {
                throw new IOException("Config contains JSON null");
            }
            // Gson leaves absent primitive fields at zero on some runtimes. Migrate old configs explicitly.
            if (!fields.has("comboTimerEnabled")) loaded.comboTimerEnabled = true;
            if (!fields.has("recordSoundEnabled")) loaded.recordSoundEnabled = true;
            if (!fields.has("recordSoundVolume")) loaded.recordSoundVolume = 70;
            if (!fields.has("offhandTotemWarningEnabled")) loaded.offhandTotemWarningEnabled = true;
            loaded.validate();
            logger.info("HitMetrics config loaded (best combo: {})", loaded.bestCombo);
            return loaded;
        } catch (Exception exception) {
            logger.error("Could not load HitMetrics config; defaults will be used", exception);
            return new HitMetricsConfig();
        }
    }

    public void save(Logger logger) {
        validate();
        try {
            Files.createDirectories(PATH.getParent());
            Path temporary = PATH.resolveSibling(PATH.getFileName() + ".tmp");
            Files.writeString(temporary, GSON.toJson(this), StandardCharsets.UTF_8);
            try {
                Files.move(temporary, PATH, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException unsupportedAtomicMove) {
                Files.move(temporary, PATH, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            logger.error("Could not save HitMetrics config", exception);
        }
    }

    public int argbColor() {
        try {
            return 0xFF000000 | Integer.parseInt(color.substring(1), 16);
        } catch (RuntimeException ignored) {
            return 0xFFFFFFFF;
        }
    }

    public static boolean isValidColor(String value) {
        return value != null && value.matches("#[0-9a-fA-F]{6}");
    }

    private void validate() {
        xOffset = Math.clamp(xOffset, -500, 500);
        yOffset = Math.clamp(yOffset, 0, 200);
        bestCombo = Math.max(0, bestCombo);
        recordSoundVolume = Math.clamp(recordSoundVolume, 0, 100);
        if (!isValidColor(color)) color = "#FFFFFF";
        if (layout == null) layout = Layout.VERTICAL;
        if (targetMode == null) targetMode = TargetMode.PLAYERS;
        if (order == null) order = IndicatorOrder.DISTANCE_COMBO_BEST;
    }

    public enum Layout { VERTICAL, HORIZONTAL }
    public enum TargetMode { PLAYERS, ALL_LIVING }
    public enum IndicatorOrder {
        DISTANCE_COMBO_BEST,
        DISTANCE_BEST_COMBO,
        COMBO_DISTANCE_BEST,
        COMBO_BEST_DISTANCE,
        BEST_DISTANCE_COMBO,
        BEST_COMBO_DISTANCE
    }
}
