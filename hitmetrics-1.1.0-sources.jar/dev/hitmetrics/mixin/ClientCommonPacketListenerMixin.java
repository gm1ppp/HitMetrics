package dev.hitmetrics.mixin;

import dev.hitmetrics.HitMetricsClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientCommonPacketListenerImpl.class)
abstract class ClientCommonPacketListenerMixin {
    @Inject(method = "send", at = @At("HEAD"), cancellable = true)
    private void hitmetrics$guardSwapHandsPacket(Packet<?> packet, CallbackInfo callback) {
        if (!(packet instanceof ServerboundPlayerActionPacket actionPacket)
                || actionPacket.getAction() != ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND) return;

        Minecraft client = Minecraft.getInstance();
        if (client != null && client.player != null
                && HitMetricsClient.OFFHAND_WARNING.shouldBlockReplacement(client, client.player.getMainHandItem())) {
            callback.cancel();
        }
    }
}
