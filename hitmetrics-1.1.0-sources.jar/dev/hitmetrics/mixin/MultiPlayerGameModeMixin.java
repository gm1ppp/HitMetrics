package dev.hitmetrics.mixin;

import dev.hitmetrics.HitMetricsClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(MultiPlayerGameMode.class)
abstract class MultiPlayerGameModeMixin {
    @Inject(method = "handleContainerInput", at = @At("HEAD"), cancellable = true)
    private void hitmetrics$guardOffhandTotem(
            int containerId, int slotId, int button, ContainerInput input, Player player, CallbackInfo callback
    ) {
        if (HitMetricsClient.OFFHAND_WARNING.shouldBlockContainerInput(slotId, button, input, player)) {
            callback.cancel();
        }
    }
}
