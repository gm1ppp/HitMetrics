package dev.hitmetrics.hud;

import dev.hitmetrics.HitMetricsClient;
import dev.hitmetrics.HitTracker;
import dev.hitmetrics.config.HitMetricsConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

import java.util.List;
import java.util.Locale;

@Environment(EnvType.CLIENT)
public final class HitMetricsHud {
    private HitMetricsHud() { }

    public static void register() {
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(HitMetricsClient.MOD_ID, "metrics"),
                (graphics, deltaTracker) -> render(graphics)
        );
    }

    private static void render(GuiGraphicsExtractor graphics) {
        Minecraft client = Minecraft.getInstance();
        HitTracker tracker = HitMetricsClient.TRACKER;
        if (client == null || client.player == null || client.level == null || client.options.hideGui || !tracker.hasHit()) return;

        HitMetricsConfig config = HitMetricsClient.config();
        Font font = client.font;
        if (font == null) return;

        Component distance = Component.translatable("hud.hitmetrics.distance", String.format(Locale.ROOT, "%.2f", tracker.lastDistance()));
        Component combo = comboText(config, tracker);
        Component best = Component.translatable("hud.hitmetrics.best_combo", config.bestCombo);
        List<Component> ordered = order(config.order, distance, combo, best);

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        int color = config.argbColor();

        if (config.layout == HitMetricsConfig.Layout.HORIZONTAL) {
            Component line = Component.empty()
                    .append(ordered.get(0)).append(" | ")
                    .append(ordered.get(1)).append(" | ")
                    .append(ordered.get(2));
            int x = (screenWidth - font.width(line)) / 2 + config.xOffset;
            int y = screenHeight - 22 - config.yOffset - font.lineHeight;
            graphics.text(font, line, x, y, color, false);
            return;
        }

        int totalHeight = ordered.size() * font.lineHeight;
        int y = screenHeight - 22 - config.yOffset - totalHeight;
        for (Component line : ordered) {
            int x = (screenWidth - font.width(line)) / 2 + config.xOffset;
            graphics.text(font, line, x, y, color, false);
            y += font.lineHeight;
        }
    }

    private static Component comboText(HitMetricsConfig config, HitTracker tracker) {
        Component combo = Component.translatable("hud.hitmetrics.combo", tracker.combo());
        if (!config.comboTimerEnabled || tracker.combo() <= 0) return combo;

        float seconds = tracker.remainingSeconds();
        int timerColor = seconds >= 3.0F ? 0x55FF55 : seconds >= 1.5F ? 0xFFFF55 : 0xFF5555;
        Component timer = Component.translatable(
                "hud.hitmetrics.combo_timer",
                String.format(Locale.ROOT, "%.1f", seconds)
        ).withStyle(Style.EMPTY.withColor(timerColor));
        return Component.empty().append(combo).append(" ").append(timer);
    }

    private static List<Component> order(HitMetricsConfig.IndicatorOrder order, Component distance, Component combo, Component best) {
        return switch (order) {
            case DISTANCE_COMBO_BEST -> List.of(distance, combo, best);
            case DISTANCE_BEST_COMBO -> List.of(distance, best, combo);
            case COMBO_DISTANCE_BEST -> List.of(combo, distance, best);
            case COMBO_BEST_DISTANCE -> List.of(combo, best, distance);
            case BEST_DISTANCE_COMBO -> List.of(best, distance, combo);
            case BEST_COMBO_DISTANCE -> List.of(best, combo, distance);
        };
    }
}
