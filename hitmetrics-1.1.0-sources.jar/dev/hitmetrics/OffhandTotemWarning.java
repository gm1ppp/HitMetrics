package dev.hitmetrics;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShieldItem;

/** Blocks the first unsafe attempt to replace an offhand totem and remembers its exact replacement. */
@Environment(EnvType.CLIENT)
public final class OffhandTotemWarning {
    private ItemStack pendingReplacement;

    public boolean shouldBlockContainerInput(int slotId, int button, ContainerInput input, Player player) {
        if (input == null || player == null || player.containerMenu == null) {
            clearPending();
            return false;
        }

        AbstractContainerMenu menu = player.containerMenu;
        if (slotId < 0 || slotId >= menu.slots.size()) return false;
        Slot clickedSlot = menu.slots.get(slotId);
        if (clickedSlot == null) return false;

        ItemStack replacement = null;
        if (input == ContainerInput.SWAP && button == Inventory.SLOT_OFFHAND) {
            replacement = clickedSlot.getItem();
        } else if (isOffhandSlot(clickedSlot, player.getInventory())) {
            replacement = switch (input) {
                case PICKUP, QUICK_CRAFT -> menu.getCarried();
                case QUICK_MOVE, THROW -> ItemStack.EMPTY;
                case SWAP -> button >= 0 && button < Inventory.getSelectionSize()
                        ? player.getInventory().getItem(button)
                        : null;
                default -> null;
            };
        }

        return replacement != null && shouldBlockReplacement(Minecraft.getInstance(), replacement);
    }

    public boolean shouldBlockReplacement(Minecraft client, ItemStack requestedReplacement) {
        if (client == null || client.player == null || !HitMetricsClient.config().offhandTotemWarningEnabled) {
            clearPending();
            return false;
        }

        ItemStack offhand = client.player.getOffhandItem();
        ItemStack replacement = requestedReplacement == null ? ItemStack.EMPTY : requestedReplacement;
        if (offhand == null || !offhand.is(Items.TOTEM_OF_UNDYING)
                || replacement.is(Items.TOTEM_OF_UNDYING)
                || (!replacement.isEmpty() && replacement.getItem() instanceof ShieldItem)) {
            clearPending();
            return false;
        }

        if (pendingReplacement != null && ItemStack.matches(pendingReplacement, replacement)) {
            clearPending();
            return false;
        }

        pendingReplacement = replacement.copy();
        Component warning = replacement.isEmpty()
                ? Component.translatable("warning.hitmetrics.remove_totem")
                : Component.translatable("warning.hitmetrics.replace_totem", replacement.getHoverName());
        client.gui.getChat().addClientSystemMessage(warning);
        return true;
    }

    public void clearPending() {
        pendingReplacement = null;
    }

    private static boolean isOffhandSlot(Slot slot, Inventory inventory) {
        return slot.container == inventory && slot.getContainerSlot() == Inventory.SLOT_OFFHAND;
    }
}
