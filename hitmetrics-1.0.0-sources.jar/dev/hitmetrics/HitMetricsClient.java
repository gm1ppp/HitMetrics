package dev.hitmetrics;

import dev.hitmetrics.config.HitMetricsConfig;
import dev.hitmetrics.hud.HitMetricsHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class HitMetricsClient implements ClientModInitializer {
    public static final String MOD_ID = "hitmetrics";
    public static final Logger LOGGER = LoggerFactory.getLogger("HitMetrics");
    public static final HitTracker TRACKER = new HitTracker();
    private static HitMetricsConfig config;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Starting HitMetrics client mod");
        config = HitMetricsConfig.load(LOGGER);

        AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            TRACKER.recordAttack(player, entity);
            return InteractionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(TRACKER::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
                TRACKER.suspendForDisconnect(serverKey(client)));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
                TRACKER.resumeAfterJoin(serverKey(client)));
        HitMetricsHud.register();
        LOGGER.info("HitMetrics started successfully");
    }

    public static HitMetricsConfig config() {
        if (config == null) config = HitMetricsConfig.load(LOGGER);
        return config;
    }

    public static void replaceConfig(HitMetricsConfig replacement) {
        if (replacement == null) return;
        config = replacement;
        config.save(LOGGER);
    }

    private static String serverKey(Minecraft client) {
        if (client == null) return null;
        if (client.hasSingleplayerServer()) return "singleplayer";
        return client.getCurrentServer() == null ? null : client.getCurrentServer().ip;
    }
}
