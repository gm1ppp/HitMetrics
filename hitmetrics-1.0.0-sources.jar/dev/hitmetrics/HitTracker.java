package dev.hitmetrics;

import dev.hitmetrics.config.HitMetricsConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.UUID;

/** Holds session hit data. Only local-player attacks are passed into this class. */
@Environment(EnvType.CLIENT)
public final class HitTracker {
    private static final int TIMEOUT_TICKS = 4 * 20;

    private UUID targetId;
    private int combo;
    private int idleTicks;
    private double lastDistance;
    private boolean hasHit;
    private SuspendedCombo suspendedCombo;

    public void recordAttack(Player attacker, Entity target) {
        Minecraft client = Minecraft.getInstance();
        if (attacker == null || target == null || client.player == null || attacker != client.player) return;

        HitMetricsConfig config = HitMetricsClient.config();
        if (!(target instanceof LivingEntity)) return;
        if (config.targetMode == HitMetricsConfig.TargetMode.PLAYERS && !(target instanceof Player)) return;

        UUID attackedId = target.getUUID();
        combo = attackedId.equals(targetId) ? combo + 1 : 1;
        targetId = attackedId;
        idleTicks = 0;
        hasHit = true;

        // Snapshot from the attacker's eyes to the entity position at this exact attack callback.
        lastDistance = attacker.getEyePosition().distanceTo(target.position());
        if (combo > config.bestCombo) {
            config.bestCombo = combo;
            config.save(HitMetricsClient.LOGGER);
        }
    }

    public void tick(Minecraft client) {
        if (!hasHit || client == null || client.level == null || client.player == null) return;
        if (++idleTicks >= TIMEOUT_TICKS) {
            reset("four-second attack timeout");
            return;
        }

        if (targetId != null) {
            Entity target = client.level.getEntity(targetId);
            if (target instanceof LivingEntity living && !living.isAlive()) {
                reset("target died");
            }
        }
    }

    public void reset(String reason) {
        targetId = null;
        combo = 0;
        idleTicks = 0;
        hasHit = false;
        lastDistance = 0.0;
        HitMetricsClient.LOGGER.info("HitMetrics combo reset: {}", reason);
    }

    /** Reset while retaining a private snapshot that may be restored on the same server only. */
    public void suspendForDisconnect(String serverKey) {
        suspendedCombo = hasHit && serverKey != null
                ? new SuspendedCombo(serverKey, targetId, combo, idleTicks, lastDistance)
                : null;
        reset("disconnected from server");
    }

    public void resumeAfterJoin(String serverKey) {
        SuspendedCombo suspended = suspendedCombo;
        suspendedCombo = null;
        if (suspended == null || serverKey == null || !serverKey.equals(suspended.serverKey())) return;
        targetId = suspended.targetId();
        combo = suspended.combo();
        idleTicks = suspended.idleTicks();
        lastDistance = suspended.lastDistance();
        hasHit = true;
        HitMetricsClient.LOGGER.info("HitMetrics combo restored after reconnecting to the same server");
    }

    public boolean hasHit() { return hasHit; }
    public int combo() { return combo; }
    public double lastDistance() { return lastDistance; }

    private record SuspendedCombo(String serverKey, UUID targetId, int combo, int idleTicks, double lastDistance) { }
}
